export class Message {
    message: String;
    description: String;
    userId: String
}
